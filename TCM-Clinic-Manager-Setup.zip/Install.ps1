$ErrorActionPreference = 'Stop'
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'TCMClinic'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item (Join-Path $src 'TCM-Clinic-Manager.html') $dest -Force
Copy-Item (Join-Path $src 'clinic.ico') $dest -Force

$browsers = @(
  "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$exe = $browsers | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $exe) { Write-Host 'Microsoft Edge or Google Chrome is required.'; exit 1 }

$page    = (Join-Path $dest 'TCM-Clinic-Manager.html')
$url     = 'file:///' + ($page -replace '\\','/')
$profile = Join-Path $dest 'data'   # all clinic data is kept in this folder
$launch    = "--app=`"$url`" --user-data-dir=`"$profile`" --no-first-run --no-default-browser-check"

$ws = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $lnk = $ws.CreateShortcut((Join-Path $dir 'TCM Clinic Manager.lnk'))
  $lnk.TargetPath = $exe
  $lnk.Arguments = $launch
  $lnk.IconLocation = (Join-Path $dest 'clinic.ico')
  $lnk.WorkingDirectory = $dest
  $lnk.Save()
}
Write-Host ''
Write-Host 'Installed! A "TCM Clinic Manager" icon is now on your Desktop and in the Start menu.'
Write-Host "Your clinic data is stored in: $profile"
Write-Host 'Remember to download a backup regularly (Settings & Backup).'
