@echo off
echo Installing TCM Clinic Manager...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
echo.
pause
